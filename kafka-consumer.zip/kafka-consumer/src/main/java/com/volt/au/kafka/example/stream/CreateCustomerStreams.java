package com.volt.au.kafka.example.stream;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface CreateCustomerStreams {

    String INPUT = "readCustomerChannel";

    @Input(INPUT)
    SubscribableChannel readCustomerChannel();
}
