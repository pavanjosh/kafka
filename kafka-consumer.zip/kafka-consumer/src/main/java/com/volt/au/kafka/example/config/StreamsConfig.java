package com.volt.au.kafka.example.config;

import com.volt.au.kafka.example.stream.CreateCustomerStreams;
import org.springframework.cloud.stream.annotation.EnableBinding;


@EnableBinding(CreateCustomerStreams.class)
public class StreamsConfig {
}
