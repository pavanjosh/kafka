package com.volt.au.kafka.example.listener;

import com.volt.au.kafka.example.model.CustomerModel;
import com.volt.au.kafka.example.stream.CreateCustomerStreams;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CreateCustomerListener {

    @StreamListener(CreateCustomerStreams.INPUT)
    public void createCustomer(@Payload CustomerModel customerModel){
        log.info("Received customer: {}", customerModel);
    }
}
