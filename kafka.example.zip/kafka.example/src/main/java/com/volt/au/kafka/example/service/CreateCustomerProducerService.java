package com.volt.au.kafka.example.service;


import com.volt.au.kafka.example.model.CustomerModel;
import com.volt.au.kafka.example.stream.CreateCustomerStreams;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

@Service
@Slf4j
public class CreateCustomerProducerService {

    @Autowired
    CreateCustomerStreams createCustomerStreams;

    public void sendCreateCustomer(CustomerModel customerModel)
    {
        MessageChannel messageChannel = createCustomerStreams.createCustomerChannel();
        messageChannel.send(MessageBuilder.withPayload(customerModel).setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON).build());
    }

}
