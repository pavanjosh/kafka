package com.volt.au.kafka.example.controller;

import com.volt.au.kafka.example.model.CustomerModel;
import com.volt.au.kafka.example.service.CreateCustomerProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateCustomerController {

    @Autowired
    private CreateCustomerProducerService createCustomerProducerService;

    @PostMapping("/customer")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void createCustomer(@RequestBody CustomerModel customerModel){
        createCustomerProducerService.sendCreateCustomer(customerModel);

    }
}
