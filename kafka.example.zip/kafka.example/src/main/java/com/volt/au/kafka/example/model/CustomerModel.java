package com.volt.au.kafka.example.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CustomerModel {
    private String name;
    private String address;
    private int age;
}
